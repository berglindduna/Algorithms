package s4;

import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.DirectedCycle;
import edu.princeton.cs.algs4.BreadthFirstDirectedPaths;

public class SAP {
	
	private final Digraph digraph;
	
	// constructor takes a digraph ( not necessarily a DAG )
	public SAP (Digraph G) {
		digraph = new Digraph(G);
		
		DirectedCycle cycle = new DirectedCycle(digraph);
		
		if (cycle.hasCycle() || digraph.V() == 0)
			throw new IllegalArgumentException("Graph is not acyclic");
		
		int a = 0;
		
		for (int i = 0; i < digraph.V(); i++) {
			if (!digraph.adj(i).iterator().hasNext()) 
				a++;
			
			if (a > 2)
				throw new IllegalArgumentException("Graph is not rooted");
		}
	}
	
	private void checkRange (int v) {
		if (v > (digraph.V() - 1))
			throw new java.lang.IndexOutOfBoundsException();
	}
	
	private void checkRange (Iterable <Integer> A) {
		for (Integer i: A)
			checkRange(i);
	}
	
	// length of shortest ancestral path between v and w; -1 if no such path
	public int length ( int v , int w) {
		Stack<Integer> vStack = new Stack<Integer>();
		Stack<Integer> wStack = new Stack<Integer>();
		vStack.push(v);
		vStack.push(w);
		return (length(vStack, wStack));
	}
	
	// a shortest common common ancestor of v and w; -1 if no such path
	public int ancestor ( int v , int w) {
		Stack<Integer> vStack = new Stack<Integer>();
		Stack<Integer> wStack = new Stack<Integer>();
		vStack.push(v);
		vStack.push(w);
		return (ancestor(vStack, wStack));
	}
	
	// length of shortest ancestral path of vertex subsets A and B ; -1 if no such path
	public int length ( Iterable < Integer > A , Iterable < Integer > B) {
		checkRange(A);
		checkRange(B);
		shortestPath temp = new shortestPath(digraph, A, B);
		return (temp.getMinLength());
	}
	
	// a shortest common ancestor of vertex subsets A and B; -1 if no such path
	public int ancestor ( Iterable < Integer > A , Iterable < Integer > B) {
		checkRange(A);
		checkRange(B);
		shortestPath temp = new shortestPath(digraph, A, B);
		return (temp.getAncestor());
	}
	
	// do unit testing of this class
	 public static void main(String[] args) {
		 
	 }

}

class shortestPath {
	private int V;
	private int ancestor;
	private int minLength;
	private BreadthFirstDirectedPaths a, b;
	
		
	public shortestPath (Digraph G, Iterable<Integer> A, Iterable<Integer> B) {
		minLength = -1;
		ancestor = -1;
		V = G.V();
		a = new BreadthFirstDirectedPaths(G, A);
		b = new BreadthFirstDirectedPaths(G, B);
		 
		for (int i = 0; i < V; i++) {
			
			if (a.hasPathTo(i) && b.hasPathTo(i)) {
				
				int temp = a.distTo(i) + b.distTo(i);
				
				if (minLength < 0 || minLength >= temp) {
					minLength = temp;
					ancestor = i;
				}
			}
		}
	}
	
	public int getAncestor() {return ancestor;}
	
	public int getMinLength() {return minLength;}
}
